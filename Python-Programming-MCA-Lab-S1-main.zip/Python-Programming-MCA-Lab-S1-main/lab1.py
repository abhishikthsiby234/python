F_name = input("Enter your first name: ")
L_name = input("Enter your last name: ")
print("Greetings!!!", F_name, L_name)
