word=input("enter the word : ")
reverse=word[-1]+word[1:-1]+word[0]
print(reverse)