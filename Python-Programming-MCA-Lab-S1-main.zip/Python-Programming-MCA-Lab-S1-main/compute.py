n=(input("enter any value : "))
out=int(n) + int(n * 2) + int(n * 3)
print("output of n+nn+nnn = ",out)