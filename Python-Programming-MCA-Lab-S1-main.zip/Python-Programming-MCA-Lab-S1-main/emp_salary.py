b_pay = float(input("enter the bpay of employee : "))
HRA = 0.10 * b_pay
TA = 0.05 * b_pay
T_salary = b_pay+HRA+TA
print("HRA of 10% = ",HRA)
print("TA of 5% = ",TA)
print("Employee Salary = ",T_salary)
