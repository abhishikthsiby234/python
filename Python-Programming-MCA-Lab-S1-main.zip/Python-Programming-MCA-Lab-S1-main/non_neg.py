word=input("Enter any word : ")
non_neg=int(input("Enter any non negative number : "))
output=word * non_neg
print(output)