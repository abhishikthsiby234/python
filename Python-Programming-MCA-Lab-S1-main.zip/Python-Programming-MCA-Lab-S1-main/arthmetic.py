n1=int(input("enter any first number : "))
n2=int(input("enter any second number : "))
print("ADDITION")
add=n1+n2
print(n1," + ",n2," = ",add)
print("SUBSTRACTION")
sub=n1-n2
print(n1," - ",n2," = ",sub)
print("MULTIPLICATION")
mult=n1*n2
print(n1," * ",n2," = ",mult)
print("DIVISION")
div=n1/n2
print(n1," / ",n2," = ",div)
print("REMAINDER")
rem=n1%n2
print(n1," % ",n2," = ",rem)