word=input("enter the word : ")
result=word[0]+word[1:].replace(word[3],'$')
print(result)
