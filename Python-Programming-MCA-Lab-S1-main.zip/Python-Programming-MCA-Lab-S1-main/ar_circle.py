r=int(input("Enter the radius of the circle : "))
pi = 3.14
Area = pi * r * r
print("Area of the circle = ",Area)